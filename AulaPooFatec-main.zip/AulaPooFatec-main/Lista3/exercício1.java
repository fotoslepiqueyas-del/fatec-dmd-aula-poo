package Lista3;

public class exercício1 {

	public static void main(String[] args) {
		for (int i = 1; i <= 10; i++) {
            System.out.println(i);
        }
    }
}

