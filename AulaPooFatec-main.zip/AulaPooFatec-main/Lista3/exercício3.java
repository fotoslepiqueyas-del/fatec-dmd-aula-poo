package Lista3;

public class exercício3 {

	public static void main(String[] args) {
		for (int i = 2; i <= 50; i += 2) {
            System.out.println(i);
        }
    }
}